# simpledlna
基于cling实现的Android投屏方案

# 源码解析参考

>[基于cling实现的Android投屏方案——简书](https://www.jianshu.com/p/9f54d8c4e502)

>[基于cling实现的Android投屏方案——github博客](https://ykbjson.github.io/2019/07/18/%E5%9F%BA%E4%BA%8Ecling%E5%AE%9E%E7%8E%B0%E7%9A%84Android%E6%8A%95%E5%B1%8F%E6%96%B9%E6%A1%88/)
